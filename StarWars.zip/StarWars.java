
using namespace std;

class ForceBeing {
  private: 
  int power_level;
  String name;
  boolean evil;

  protected:
   ForceBeing(int level) {
      power_level = level;
  }

  void setPowerLevel(int level) {
    power_level = level;
  }

  void setName(String characterName) {
    name = characterName;
  }

  public:
   int getPowerLevel() {
    return power_level;
  }

  String getName() {
    return name;
  }

  void setEvil() {
    evil = true;
  }

 void setGood() {
    evil = false;
  }

}

class Jedi: public ForceBeing {
  
  public:
     Jedi(String jediName, int level) {
      super(level);
      setName(jediName);
      setGood();
  }

  int getPowerLevel() {
    return super.getPowerLevel() + 1;
  }
}

class Sith: public ForceBeing {
  
  public: 
  Sith(String sithName, int level) {
      super(level);
      setName(sithName);
      setEvil();
  }

   int getPowerLevel() {
    return super.getPowerLevel() - 1;
  }

   String getName() {
    return "Sith Lord: " + super.getName();
  }
}

 class StarWars {

    public:
     static String getWinner(ForceBeing player1, ForceBeing player2) {
        return player1.getPowerLevel() > player2.getPowerLevel() ? player1.getName() : player2.getName();
    }

    static void printWinner(String winner) {
        cout << "The winner is: " + winner;
    }

    int main() {
        Sith darthVader = new Sith("Darth Vader",100);
        Jedi lukeSkyWalker = new Jedi("Luke Skywalker",99);
        printWinner(getWinner(darthVader, lukeSkyWalker));
    }
}